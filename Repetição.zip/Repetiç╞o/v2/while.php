<?php
$tablemult = $_POST["num_while"];
$i = 1;
while ($i <=10) {
    $result = $tablemult * $i;
    echo ("$tablemult * $i = $result<br>");
    $i++;
}
?>
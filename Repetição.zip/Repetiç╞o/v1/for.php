<?php
$tablemult = $_POST["num_for"];
for ($i = 1; $i <= 10; $i++) {
    $result = $tablemult * $i;
    echo ("$tablemult * $i = $result <br>");
}
?>
 
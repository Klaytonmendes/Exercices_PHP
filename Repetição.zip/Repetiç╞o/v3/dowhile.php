<?php
$tablemult = $_POST["num_dowhile"];
$i = 1;
do {
    $result = $tablemult * $i;
    echo ("$tablemult * $i = $result<br>");
    $i++;
}
while ($i <=10)
?>